from prediction.predictor import PhenotypePredictor
